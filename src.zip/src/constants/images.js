import logo from "../asset/Vishwas-Refoils-LLP-Logo.png";
import yellow_head from "../asset/yellow_head_img.png";

import sunflower_can from "../asset/sunflower_can.png";
import groundnut_can from "../asset/groundnut_can.png";
import cotton_can from "../asset/cotton_can.png";
import corn_can from "../asset/corn_can.png";
import palmolein_can from "../asset/palmolein_can.png";
import soyabean_can from "../asset/soyabean_can.png";

import about_welcome from "../asset/about_welcome.jpeg";

import slider_product_img_1 from "../asset/Product-Slider-1.png";
import slider_product_img_2 from "../asset/Product-Slider-2.png";
import slider_product_img_3 from "../asset/Product-Slider-3.png";
import slider_product_img_4 from "../asset/cotton.png";
import slider_product_img_5 from "../asset/Product-Slider-5.png";
import slider_product_img_6 from "../asset/Product-Slider-6.png";

import amazon from "../asset/amazon.png";
import Flipkart_logo from "../asset/Flipkart_logo.png";
import udaan_logo from "../asset/udaan_logo.png";

import footer_img from "../asset/Footer_img.png";
import oil_droplets from "../asset/oil_droplets.jpg";
import section_bg1 from "../asset/section_bg1.png";

import sunflower from "../asset/sun.jpeg";
import flower from "../asset/flower.png";
import bg_product from "../asset/bg_product.jpeg";
import SunflowerOil_Products from "../asset/SunflowerOil_Products.png";
import Refined_Sunflower_Oil_set from "../asset/Refined_Sunflower_Oil_set.png";
import GroundnutOil_Products from "../asset/GroundnutOil_Products.png";
import groundnut_Oil_set from "../asset/groundnut_Oil_set.png";
import CottonseedOil_Products from "../asset/CottonseedOil_Products.png";
import Refined_Cottonseed_Oil_set from "../asset/Refined_Cottonseed_Oil_set.png";
import CornOil_Products from "../asset/CornOil_Products.png";
import Refined_Corn_Oil_set from "../asset/Refined_Corn_Oil_set.png";
import SoyabeanOil_Products from "../asset/SoyabeanOil_Products.png";
import All_Soya from "../asset/All_Soya.png";
import Palmolean_Products from "../asset/Palmolean_Products.png";
import Refined_PalmoleinOil_set from "../asset/Refined_PalmoleinOil_set.png";
import castor_Singlepro from "../asset/castor_Singlepro.png";
import Castor_Oil_set from "../asset/Castor_Oil_set.png";
import bottle from "../asset/bottle.png";
import pouch from "../asset/pouch.png";
import pouch1 from "../asset/pouch1.png";
import tin from "../asset/tin.png";
import can_big from "../asset/can_big.png";
import can_small from "../asset/can_small.png";
import bucket_icon from "../asset/bucket_icon.png";
import tap_jar from "../asset/tap_jar.png";
import family_homeabout from "../asset/family_homeabout.jpg";
import img_benifit from "../asset/img_benifit.jpeg";
import hands_holding_heart from "../asset/hands_holding_heart.png";
import Cholesterol from "../asset/cholesterol.png";
import dumbbell from "../asset/dumbbell.png";
import food from "../asset/food.png";
import home_bg from "../asset/home_bg.png";
import team from "../asset/team.jpeg";

// import about_certificate_1 from "../asset/about-certificate_1.jpeg";
// import about_certificate_2 from "../asset/about-certificate_2.jpeg";
import certificate1 from "../asset/certificate1.jpeg";
import certificate2 from "../asset/certificate2.jpeg";
import about_certificate_3 from "../asset/about-certificate_3.jpeg";
import bg_image from "../asset/bg_image.jpeg";
import our_jour_img from "../asset/ourjourimg.png";
import linkdin from "../asset/linkdin.png";
import twitter from "../asset/twitter.png";
import professional_development from "../asset/professional_development.png";
import salary from "../asset/salary.png";
import soft_skills from "../asset/soft_skills.png";
import carrer_cartoon_img from "../asset/carrer_cartoon_img.webp";
import person1 from "../asset/person1.jpeg";
import person2 from "../asset/person2.jpeg";
import person3 from "../asset/person3.jpeg";

import corn_hero_bg from "../asset/corn_hero_bg.jpg";
import cotton_hero_bg from "../asset/cotton_hero_bg.jpg";
import groundnut_hero_bg from "../asset/groundnut_hero_bg.jpg";
import palmolean_hero_bg from "../asset/palmolean_hero_bg.jpeg";
import soy_hero_bg from "../asset/soya_hero_bg.jpg";
import sunflower_hero_bg from "../asset/sunflower_hero_bg.jpeg";

import corn_hero from "../asset/corn_hero.png";
import cotton_hero from "../asset/cotton_hero.png";
import groundnut_hero from "../asset/groundnut_hero.png";
import groundnut_hero_change from "../asset/groundnut_hero_change.png";
import palmolean_hero from "../asset/palmolean_hero.png";
import soya_hero from "../asset/soya_hero.png";
import sunflower_hero from "../asset/sunflower_hero.png";

import corn_hero_big from "../asset/corn_hero_big.png";
import cotton_hero_big from "../asset/cotton_hero_big.png";
import groundnut_hero_big from "../asset/groundnut_hero_change_big.png";
import groundnut_hero_change_big from "../asset/groundnut_hero_change_big.png";
import palmolean_hero_big from "../asset/palmolean_hero_change_big.png";
import palmolean_hero_change_big from "../asset/palmolean_hero_change_big.png";
import soya_hero_big from "../asset/soya_hero_big.png";
import sunflower_hero_big from "../asset/sunflower_hero_big.png";

import insta_logo from "../asset/insta-img1.png";
import fb_logo from "../asset/fb-social-img.png";
import linkedin_logo from "../asset/linkdin-img.png";
import twitter_logo from "../asset/twitter_logo.png";
import youtube_logo from "../asset/Youtube_logo.png";

import management from "../asset/management.png";
import financialreport from "../asset/financialreport.png";
import listing from "../asset/listing.png";
import annualreport from "../asset/annualreport.png";
import policy from "../asset/policy.png";
import shareholding from "../asset/shareholding.png";
import announcement from "../asset/announcement.png";
import Prospectus from "../asset/Prospectus.png";
import corporategov from "../asset/corporategov.png";

// import diff_size_img1 from "../asset/diff-size-img1.jpeg";
// import diff_size_img2 from "../asset/diff-size-ing2.jpeg";
// import diff_size_img3 from "../asset/diff-size-img3.jpeg";
// import diff_size_img4 from "../asset/diff-size-img4.jpeg";
import rec_1 from "../asset/res_1.jpeg";
import rec_2 from "../asset/res_2.jpeg";
import rec_3 from "../asset/res_3.jpeg";
import rec_4 from "../asset/res_4.jpeg";
// import rec_last_img from "../asset/rec-last-img.jpeg";
// import rec_home_img from "../asset/rec-home-img.jpeg";
// import recipe_home_1 from "../asset/recipe_home_1.png";
// import recipe_home_2 from "../asset/recipe_home_2.png";
// import recipe_home_3 from "../asset/recipe_home_3.png";
// import recipe_home_4 from "../asset/recipe_home_4.png";
// import Footer_2 from "../asset/Footer_2.png";
import rec_pavbhaji_detail from "../asset/Pav-Bhaji.png";
import rec_dal_baati_churma from "../asset/Dal-Bati.png";
import rec_fafdajalebi from "../asset/Fafda-Jalebi.png";
import rec_palak_paneer from "../asset/Palak-Paneer.png";
import footer_black_bg from "../asset/footer_black_bg.jpeg";

export default {
  logo,
  sunflower_can,
  groundnut_can,
  cotton_can,
  corn_can,
  castor_Singlepro,
  Castor_Oil_set,
  palmolein_can,
  soyabean_can,
  about_welcome,
  slider_product_img_1,
  slider_product_img_2,
  slider_product_img_3,
  slider_product_img_4,
  slider_product_img_5,
  slider_product_img_6,
  yellow_head,
  amazon,
  Flipkart_logo,
  udaan_logo,
  footer_img,
  oil_droplets,
  sunflower,
  bg_product,
  SunflowerOil_Products,
  Refined_Sunflower_Oil_set,
  GroundnutOil_Products,
  groundnut_Oil_set,
  CottonseedOil_Products,
  Refined_Cottonseed_Oil_set,
  CornOil_Products,
  Refined_Corn_Oil_set,
  SoyabeanOil_Products,
  All_Soya,
  Palmolean_Products,
  Refined_PalmoleinOil_set,
  bottle,
  pouch,
  pouch1,
  section_bg1,
  can_small,
  bucket_icon,
  tap_jar,
  can_big,
  tin,
  flower,
  family_homeabout,
  img_benifit,
  hands_holding_heart,
  Cholesterol,
  dumbbell,
  food,
  home_bg,
  team,
  // about_certificate_1,
  // about_certificate_2,
  certificate1,
  certificate2,
  about_certificate_3,
  bg_image,
  our_jour_img,
  linkdin,
  twitter,
  professional_development,
  salary,
  soft_skills,
  carrer_cartoon_img,
  person1,
  person2,
  person3,
  corn_hero_bg,
  cotton_hero_bg,
  groundnut_hero_bg,
  palmolean_hero_bg,
  soy_hero_bg,
  sunflower_hero_bg,
  corn_hero,
  corn_hero_big,
  cotton_hero,
  cotton_hero_big,
  groundnut_hero,
  groundnut_hero_big,
  groundnut_hero_change,
  groundnut_hero_change_big,
  palmolean_hero,
  palmolean_hero_big,
  palmolean_hero_change_big,
  soya_hero,
  soya_hero_big,
  sunflower_hero,
  sunflower_hero_big,
  insta_logo,
  fb_logo,
  linkedin_logo,
  twitter_logo,
  youtube_logo,

  management,
  financialreport,
  listing,
  annualreport,
  policy,
  shareholding,
  announcement,
  Prospectus,
  corporategov,

  rec_1,
  rec_2,
  rec_3,
  rec_4,

  rec_fafdajalebi,
  rec_dal_baati_churma,
  rec_pavbhaji_detail,
  rec_palak_paneer,

  footer_black_bg,
};
