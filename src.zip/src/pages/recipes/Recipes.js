import React from "react";
import RecipesComp from "../../component/recipes_comp/RecipesComp";

const Recipes = () => {
  return (
    <div>
      <RecipesComp />
    </div>
  );
};

export default Recipes;
