import React from "react";
import SoyabeanSinglepro from "../../component/soyabean_singlepro/SoyabeanSinglepro";

const Soyabean = () => {
  return (
    <div>
      <SoyabeanSinglepro />
    </div>
  );
};

export default Soyabean;
