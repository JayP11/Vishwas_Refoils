import React from 'react'
import CastorSinglepro from "../../component/castorsinglepro/CastorSinglepro";

const Castor = () => {
  return (
    <div><CastorSinglepro/></div>
  )
}

export default Castor