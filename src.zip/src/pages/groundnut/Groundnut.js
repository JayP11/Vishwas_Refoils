import React from 'react'
 import GroundnutSinglepro from '../../component/groundnut_singlepro/GroundnutSinglepro';

const Groundnut = () => {
  return (
    <div>
      {/* <HeroGroundnut /> */}
      <GroundnutSinglepro/>
    </div>
  );
}

export default Groundnut