import React from "react";
import CornSinglepro from "../../component/corn_singlepro/CornSinglepro";

const Corn = () => {
  return (
    <div>
      {/* <HeroGroundnut /> */}
      <CornSinglepro />
    </div>
  );
};

export default Corn;
