import React from "react";
import ContactUsCards from "../../component/contactus_cards/ContactUsCards";
import ContactUsmain from "../../component/contactusmain/ContactUsmain";
// import ContactUsmain from "../../component/contactusmai\bn/ContactUsmai\bn";

const ContactUS = () => {
  return (
    <div>
      <ContactUsCards />
      <ContactUsmain />
    </div>
  );
};

export default ContactUS;
