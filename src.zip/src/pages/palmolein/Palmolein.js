import React from 'react'
import PalmoleinSinglepro from '../../component/palmolein_singlepro/PalmoleinSinglepro'

const palmolein = () => {
  return (
    <div><PalmoleinSinglepro/></div>
  )
}

export default palmolein