import React from "react";
 import SunflowerSinglepro from "../../component/sunflower_singlepro/SunflowerSinglepro";

const Sunflower = () => {
  return (
    <div>
      {/* <HeroSunflower /> */}
      <SunflowerSinglepro />
    </div>
  );
};

export default Sunflower;
