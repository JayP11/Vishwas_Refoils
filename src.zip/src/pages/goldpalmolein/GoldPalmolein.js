import React from 'react'
import GoldPalmoleinSinglepro from '../../component/goldpalmolein_singlepro/GoldPalmoleinSinglepro'

const GoldPalmolein = () => {
  return (
    <div><GoldPalmoleinSinglepro/></div>
  )
}

export default GoldPalmolein