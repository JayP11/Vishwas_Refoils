import React from "react";
import Cottonseed_Singlepro from "../../component/cottonseed_singlepro/Cottonseed_Singlepro";

const Cottonseed = () => {
  return (
    <div>
      <Cottonseed_Singlepro />
    </div>
  );
};

export default Cottonseed;
