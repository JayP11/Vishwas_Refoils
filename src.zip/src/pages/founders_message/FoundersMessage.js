import React from "react";
import Message from "../../component/message/Message";

const FoundersMessage = () => {
  return (
    <div>
      <Message />
    </div>
  );
};

export default FoundersMessage;
